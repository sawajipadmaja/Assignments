package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions
( 	features="classpath:features", 
	glue="", 
	tags="",
	plugin="html:target/reports/cucumber-reports.html", 
	dryRun=false
		
		)

// tags= blank means run everything eg @tag, @tag1 in feature file
//dryrun = just run it dont execute anything
public class TestRunner {

}
