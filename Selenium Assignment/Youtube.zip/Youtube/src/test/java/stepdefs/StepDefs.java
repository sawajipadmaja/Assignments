package stepdefs;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
//import junit.framework.Assert;

public class StepDefs {

WebDriver driver;
Scenario scn;

@Before		
public void beforeMethodSetUp(Scenario s) {
	this.scn = s;
}		//hook method for logs


@Given("I open chrome browser")
public void i_open_chrome_browser() {
	driver = new ChromeDriver();
	
	scn.log("Chrome is opened");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	
}


@Given("I navigate to {string}")
public void i_navigate_to(String url) {
	driver.get(url);
	scn.log("navigated to url: " + url);
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
}
/*
@When("I click on search")
public void i_click_on_search() {

	driver.findElement(By.id("search-icon-legacy")).click(); //[@id="search-icon-legacy"]
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
}
*/

@When("I search Java tutorial")
public void i_search_java_tutorial() {
	//*[@id="search-form"]
	//*[@id="search-form"]
	
	//WebDriverWait wait= (new WebDriverWait(driver, 5));
	//wait.until(ExpectedConditions . elementToBeClickable (By.id("search-form")));
	
	//driver.findElement(By.id("search-form")).click();
	driver.findElement(By.id("search-input")).sendKeys("Java Tutorial");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	scn.log("searched for Java Tutorial");
	driver.findElement(By.id("search-icon-legacy")).click(); //[@id="search-icon-legacy"]
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
}



@Then("I land on Java tutorial - YouTube search page")
public void i_land_on_java_tutorial_you_tube_search_page() {
	String exp = "Java Tutorial - YouTube";
	String act = driver.getTitle();
    Assert.assertEquals("Page title validation", exp, act);
    driver.close();
}


@When("I search Shastriya Sangeet")
public void i_search_shastriya_sangeet() {
	driver.findElement(By.id("search-input")).sendKeys("Shastriya Sangeet");
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	scn.log("searched for Shastriya Sangeet");
	driver.findElement(By.id("search-icon-legacy")).click(); //[@id="search-icon-legacy"]
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
}


@Then("I land on Shastriya Sangeet - YouTube search page")
public void i_land_on_shastriya_sangeet_you_tube_search_page() {
	String exp = "Shastriya Sangeet - YouTube";
	String act = driver.getTitle();
    Assert.assertEquals("Page title validation", exp, act);
    driver.close();
}


@When("I search {string}")
public void i_search(String str) {
	driver.findElement(By.id("search-form")).sendKeys(str);
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	scn.log("searched for: "+ str);
	driver.findElement(By.id("search-icon-legacy")).click(); //[@id="search-icon-legacy"]
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
}

@Then("I land on {string} search page")
public void i_land_on_search_page(String str) {
	String exp = str;
	String act = driver.getTitle();
    Assert.assertEquals("Page title validation", exp, act);
    driver.close();
}
@Then("I click on Capgemini YT page")
public void i_click_on_capgemini_yt_page() {
	
	String exp = "Capgemini";
	WebElement act = driver.findElement(By.id("channel-title"));
    Assert.assertEquals("Channel name validation", exp, act);
    scn.log("channel name validated");
	driver.findElement(By.id("channel-title")).click();
	
	driver.close();
	
}







}
